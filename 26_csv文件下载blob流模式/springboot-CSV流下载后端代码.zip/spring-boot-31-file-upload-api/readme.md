# 资料

SpringBoot实现本地文件上传和OSS文件上传 + 富文本

作者：狂神飞哥
https://www.bilibili.com/video/BV1C3411b7wt?p=8&spm_id_from=pageDriver

# 知识要点

通过这次课程掌握实现文件上传下载背后的思想原理，重点在于**设计思想**和**理论基础**

# 重点课程

P8:让外部请求访问服务器资源，静态资源访问映射

P9:模拟实战开发的yml配置环境隔离 dev prod