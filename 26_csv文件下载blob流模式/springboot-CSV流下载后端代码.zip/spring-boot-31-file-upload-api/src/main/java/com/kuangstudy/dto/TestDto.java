package com.kuangstudy.dto;

import lombok.Data;

@Data
public class TestDto {
    private String param1;
    private String param2;
}
